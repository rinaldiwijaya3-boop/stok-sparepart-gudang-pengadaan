# Stok Sparepart Gudang Pengadaan

Versi baru berdasarkan Monitoring_Gudang_Pusat(2).html.

## GitHub Pages
1. Ekstrak ZIP ini.
2. Unggah `index.html`, `.nojekyll`, dan `README.md` ke root repository GitHub.
3. Ganti file lama jika diminta, lalu Commit changes.
4. Tunggu GitHub Pages memperbarui situs.

Catatan: aplikasi menyimpan data di browser (localStorage). Ekspor/cadangkan data sebelum mengganti versi lama. Penyimpanan ini tidak menyinkronkan data antar pengguna.
